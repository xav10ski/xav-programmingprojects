package log;

import java.util.HashMap;
import java.util.LinkedList;

public class HashingTests {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	      LinkedList<String> linkedlist = new LinkedList<String>();

		HashMap<Integer,Integer> map = new HashMap<Integer,Integer>();
		
		map.put(7878, 8);
		map.put(7878, 9);
		map.put(7878, 1);

		System.out.println(map.get(7878));


	}

}

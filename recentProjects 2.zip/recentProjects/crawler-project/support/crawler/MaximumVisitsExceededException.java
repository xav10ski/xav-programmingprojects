/*
 * Copyright 2017 Marc Liberatore.
 */

package crawler;

@SuppressWarnings("serial")
public class MaximumVisitsExceededException extends Exception {
}
